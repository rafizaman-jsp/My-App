import React, { useState } from "react";
import {
  TouchableOpacity,
  Text,
  View,
  StyleSheet,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import HomeScreen from "./screens/HomeScreen";
import AboutScreen from "./screens/AboutScreen";
import RegistrationScreen from "./screens/Registration";
import CourseDashboard from "./screens/CourseDashboard";
import StudentProfileScreen from "./screens/StudentProfile";
import EmployeeDirectoryScreen from "./screens/EmployeDirectory";
import StudentRegistrationScreen from "./screens/StudentRegistration";
import LoginScreen from "./screens/LoginScreen";
import PatientRegistrationScreen from "./screens/PatientRegistrationScreen";

const Stack = createNativeStackNavigator();

const menuItems = [
  { title: "Home", screen: "Home" },
  { title: "About", screen: "About" },
  { title: "Registration", screen: "Registration" },
  { title: "Course Dashboard", screen: "CourseDashboard" },
  { title: "Student Profile", screen: "StudentProfile" },
  { title: "Student Registration", screen: "StudentRegistration" },
  { title: "Employee Directory", screen: "EmployeeDirectory" },
  { title: "Login", screen: "LoginScreen" },
  { title: "Patient Registration", screen: "PatientRegistrationScreen" },
];

function MenuDropdown({ navigation }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleNavigate = (screenName: string) => {
    setMenuOpen(false);
    navigation.navigate(screenName);
  };

  return (
    <View style={styles.menuWrapper}>
      <TouchableOpacity
        onPress={() => setMenuOpen((prev) => !prev)}
        style={styles.menuButton}
      >
        <Text style={styles.menuIcon}>☰</Text>
      </TouchableOpacity>

      {menuOpen && (
        <View style={styles.dropdown}>
          {menuItems.map((item) => (
            <TouchableOpacity
              key={item.screen}
              style={styles.dropdownItem}
              onPress={() => handleNavigate(item.screen)}
            >
              <Text style={styles.dropdownText}>{item.title}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );
}

export default function Navigation({
  theme,
  linking,
  onReady,
}: {
  theme?: any;
  linking?: any;
  onReady?: any;
}) {
  return (
    <NavigationContainer
      theme={theme}
      linking={linking}
      onReady={onReady}
    >
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={({ navigation }) => ({
          headerStyle: {
            backgroundColor: "#000000",
          },
          headerTintColor: "#FFFFFF",
          headerTitleStyle: {
            fontWeight: "bold",
            fontSize: 20,
          },
          headerTitleAlign: "center",
          headerLeft: () => <MenuDropdown navigation={navigation} />,
          headerRight: () => (
            <TouchableOpacity
              onPress={() => alert("Settings clicked")}
              style={{ marginRight: 12 }}
            >
              <Text style={{ color: "#FFFFFF", fontSize: 22 }}>⚙️</Text>
            </TouchableOpacity>
          ),
        })}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: "Home" }}
        />

        <Stack.Screen
          name="About"
          component={AboutScreen}
          options={{ title: "About" }}
        />

        <Stack.Screen
          name="Registration"
          component={RegistrationScreen}
          options={{ title: "Registration" }}
        />

        <Stack.Screen
          name="CourseDashboard"
          component={CourseDashboard}
          options={{ title: "Course Dashboard" }}
        />

        <Stack.Screen
          name="StudentProfile"
          component={StudentProfileScreen}
          options={{ title: "Student Profile" }}
        />

        <Stack.Screen
          name="StudentRegistration"
          component={StudentRegistrationScreen}
          options={{ title: "Student Registration" }}
        />

        <Stack.Screen
          name="EmployeeDirectory"
          component={EmployeeDirectoryScreen}
          options={{ title: "Employee Directory" }}
        />

        <Stack.Screen
          name="LoginScreen"
          component={LoginScreen}
          options={{ title: "Login" }}
        />

        <Stack.Screen
          name="PatientRegistrationScreen"
          component={PatientRegistrationScreen}
          options={{ title: "Patient Registration" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  menuWrapper: {
    position: "relative",
    marginLeft: 12,
  },

  menuButton: {
    padding: 6,
    justifyContent: "center",
    alignItems: "center",
  },

  menuIcon: {
    color: "#FFFFFF",
    fontSize: 26,
    fontWeight: "bold",
  },

  dropdown: {
    position: "absolute",
    top: 42,
    left: 0,
    width: 220,
    backgroundColor: "#111111",
    borderRadius: 10,
    paddingVertical: 8,
    elevation: 8,
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    zIndex: 1000,
  },

  dropdownItem: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },

  dropdownText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "500",
  },
});
