// CourseDashboard.tsx
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Button,
  Modal,
  Pressable,
  Image,
} from "react-native";


const courseData = {
  CSE: {
    name: "Computer Science & Engineering",
    description: "Study of computation, algorithms, and software design.",
    color1: "#3498db",
    color2: "#2c3e50",
  },
  EEE: {
    name: "Electrical & Electronic Engineering",
    description: "Focuses on electrical systems, circuits, and electronics.",
    color1: "#e74c3c",
    color2: "#f39c12",
  },
  BBA: {
    name: "Bachelor of Business Administration",
    description: "Covers business management, finance, and marketing.",
    color1: "#27ae60",
    color2: "#16a085",
  },
};


export default function CourseDashboard({ navigation }) {
  const [activeCourse, setActiveCourse] = useState(null);
  const [infoMessage, setInfoMessage] = useState("");


  const openModal = (courseKey) => {
    setActiveCourse(courseKey);
    setInfoMessage(""); // Reset message when opening a new modal
  };


  const closeModal = () => {
    setActiveCourse(null);
    setInfoMessage("");
  };


  const handleMoreInfo = () => {
    setInfoMessage("Course information loaded");
  };


  const currentCourse = activeCourse ? courseData[activeCourse] : null;


  return (
    <View style={styles.container}>
      <Image
        source={require("../../assets/IUSlogo.png")}
        style={styles.logo}
        resizeMode="contain"
      />
      <Text style={styles.title}>Course Selection Dashboard</Text>


      {/* Requirement 1: Three Course Buttons */}
      <View style={styles.buttonGroup}>
        <Button title="CSE" onPress={() => openModal("CSE")} />
        <View style={styles.spacing} />
        <Button title="EEE" onPress={() => openModal("EEE")} />
        <View style={styles.spacing} />
        <Button title="BBA" onPress={() => openModal("BBA")} />
      </View>
      <View style={styles.backButton}>
        <Button title="Go Back" onPress={() => navigation.goBack()} />
      </View>


      {/* Requirement 2: Open a different Modal */}
      <Modal
        visible={activeCourse !== null}
        animationType="slide"
        transparent={true}
        onRequestClose={closeModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            {currentCourse && (
              <>
                {/* Requirement 3: Course Name */}
                <Text style={styles.courseTitle}>{currentCourse.name}</Text>


                {/* Requirement 3: Two colored box models */}
                <View style={styles.boxContainer}>
                  <View
                    style={[
                      styles.colorBox,
                      { backgroundColor: currentCourse.color1 },
                    ]}
                  />
                  <View
                    style={[
                      styles.colorBox,
                      { backgroundColor: currentCourse.color2 },
                    ]}
                  />
                </View>


                {/* Requirement 3: One description of the course */}
                <Text style={styles.description}>
                  {currentCourse.description}
                </Text>


                {/* Requirement 4: Custom Pressable named More Info */}
                <Pressable style={styles.pressable} onPress={handleMoreInfo}>
                  <Text style={styles.pressableText}>More Info</Text>
                </Pressable>


                {/* Requirement 5: Display "Course information loaded" */}
                {infoMessage !== "" && (
                  <Text style={styles.loadedText}>{infoMessage}</Text>
                )}


                {/* Requirement 3: One Close button */}
                <View style={styles.closeButtonContainer}>
                  <Button title="Close" color="#d9534f" onPress={closeModal} />
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 30,
    textAlign: "center",
  },
  logo: {
    width: 260,
    height: 100,
    marginBottom: 15,
  },
  buttonGroup: {
    width: "60%",
  },
  spacing: {
    height: 15,
  },
  backButton: {
    marginTop: 20,
    width: "60%",
  },
  modalOverlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    width: "85%",
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 25,
    alignItems: "center",
    elevation: 5,
  },
  courseTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },
  boxContainer: {
    flexDirection: "row",
    marginBottom: 15,
  },
  colorBox: {
    width: 60,
    height: 60,
    marginHorizontal: 10,
    borderRadius: 8,
  },
  description: {
    fontSize: 16,
    textAlign: "center",
    color: "#555",
    marginBottom: 20,
  },
  pressable: {
    backgroundColor: "#003366",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginBottom: 15,
  },
  pressableText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  loadedText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#27ae60",
    marginBottom: 15,
  },
  closeButtonContainer: {
    width: "100%",
    marginTop: 5,
  },
});
