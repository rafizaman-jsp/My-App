// HomeScreen.tsx
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from "react-native";

export default function HomeScreen({ navigation }) {
  const menuItems = [
    {
      title: "About",
      screen: "About",
      params: { name: "University of Scholars" },
    },
    {
      title: "Registration",
      screen: "Registration",
    },
    {
      title: "Course Dashboard",
      screen: "CourseDashboard",
    },
    {
      title: "Student Profile",
      screen: "StudentProfile",
    },
    {
      title: "Student Registration",
      screen: "StudentRegistration",
    },
    {
      title: "Employee Directory",
      screen: "EmployeeDirectory",
    },
    {
      title: "Login",
      screen: "LoginScreen",
    },
    {
      title: "Patient Registration",
      screen: "PatientRegistrationScreen",
    },
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Main Menu</Text>

      <FlatList
        data={menuItems}
        keyExtractor={(item) => item.screen}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.menuButton}
            onPress={() =>
              navigation.navigate(item.screen, item.params)
            }
          >
            <Text style={styles.menuText}>{item.title}</Text>
          </TouchableOpacity>
        )}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F4F6F8",
    padding: 20,
    justifyContent: "center",
  },

  title: {
    fontSize: 30,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 25,
    color: "#1976D2",
  },

  menuButton: {
    backgroundColor: "#1976D2",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: "center",
  },

  menuText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
  },
});