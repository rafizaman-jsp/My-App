// StudentProfile.tsx
import { View, Text, Image, StyleSheet, ScrollView, Button, TouchableOpacity } from 'react-native';


export default function StudentProfileScreen({ navigation, route }) {
    const user = route.params?.user;


    return (
        <ScrollView contentContainerStyle={styles.scrollContainer}>
            <View style={styles.container}>
                <Image
                    source={{ uri: 'https://via.placeholder.com/150' }}
                    style={styles.logo}
                />
            </View>

            <View style={styles.card}>
                <Text style={styles.title}>User Profile</Text>
                <Text style={styles.infoText}>Name: {user?.name || 'Not available'}</Text>
                <Text style={styles.infoText}>Role: {user?.role || 'Not available'}</Text>
                <Text style={styles.infoText}>User ID: {user?.userId || 'Not available'}</Text>
            </View>

            <View style={styles.buttonContainer}>
                <TouchableOpacity
                    style={styles.actionButton}
                    onPress={() => {
                        alert("Welcome to React Native!");
                    }}
                >
                    <Text style={styles.actionButtonText}>Show Welcome</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.backButton}>
                <Button title="Go Back" onPress={() => navigation.goBack()} />
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        marginBottom: 20,
    },
    scrollContainer: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    logo: {
        width: 260,
        height: 100,
        alignSelf: 'center',
        marginBottom: 20,
    },
    card: {
        backgroundColor: '#ffffff',
        borderRadius: 10,
        padding: 20,
        marginBottom: 20,
        width: '100%',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        elevation: 2,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 12,
    },
    infoText: {
        fontSize: 16,
        marginBottom: 6,
    },
    buttonContainer: {
        marginBottom: 15,
        alignItems: 'center',
    },
    actionButton: {
        backgroundColor: '#4a90e2',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 8,
    },
    actionButtonText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '600',
    },
    backButton: {
        marginTop: 15,
        alignItems: 'center',
    },
});
