//EmployDirectory.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Pressable,
  Button,
  Modal,
  StatusBar,
  ActivityIndicator,
  Image,
} from "react-native";

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  image: string;
}

export default function EmployeeDirectoryScreen({ navigation }) {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] =
    useState<Employee | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://dummyjson.com/users")
      .then((response) => response.json())
      .then((data) => {
        setEmployees(data.users);
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  }, []);

  const openModal = (employee: Employee) => {
    setSelectedEmployee(employee);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#1976D2" barStyle="light-content" />

      <Text style={styles.title}>Employee Directory</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#1976D2" />
      ) : (
        <FlatList
          data={employees}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <Pressable
              style={styles.card}
              onPress={() => openModal(item)}
            >
              <Image
                source={{ uri: item.image }}
                style={styles.avatar}
              />

              <Text style={styles.cardTitle}>
                {item.firstName} {item.lastName}
              </Text>

              <Text style={styles.cardBody}>
                {item.email}
              </Text>
            </Pressable>
          )}
        />
      )}

      <View style={styles.backButton}>
        <Button title="Go Back" onPress={() => navigation.goBack()} />
      </View>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalBackground}>
          <View style={styles.modalContainer}>
            {selectedEmployee && (
              <>
                <Image
                  source={{ uri: selectedEmployee.image }}
                  style={styles.modalAvatar}
                />

                <Text style={styles.modalTitle}>
                  {selectedEmployee.firstName} {selectedEmployee.lastName}
                </Text>

                <Text style={styles.modalText}>
                  {selectedEmployee.email}
                </Text>

                <Text style={styles.modalText}>
                  {selectedEmployee.phone}
                </Text>

                <Pressable
                  style={styles.closeButton}
                  onPress={() => setModalVisible(false)}
                >
                  <Text style={styles.closeButtonText}>Close</Text>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F4F6F8",
    paddingTop: 40,
    paddingHorizontal: 15,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 15,
    color: "#1976D2",
  },

  card: {
    backgroundColor: "#fff",
    padding: 15,
    marginBottom: 15,
    borderRadius: 12,
    alignItems: "center",
    elevation: 4,
  },

  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 10,
  },

  cardTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },

  cardBody: {
    fontSize: 16,
    color: "#666",
    marginTop: 5,
  },

  modalBackground: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
  },

  modalContainer: {
    width: "90%",
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 20,
    alignItems: "center",
  },

  modalAvatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 15,
  },

  modalTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1976D2",
    marginBottom: 15,
  },

  heading: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 10,
  },

  modalText: {
    fontSize: 16,
    color: "#444",
    marginTop: 5,
  },

  closeButton: {
    marginTop: 20,
    backgroundColor: "#1976D2",
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },

  closeText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },

  closeButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },

  backButton: {
    marginTop: 15,
  },
});