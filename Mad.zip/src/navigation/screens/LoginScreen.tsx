// src/navigation/screens/LoginScreen.tsx

import React, { useState } from 'react';
import {
    Alert,
    Platform,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';

const getApiBaseUrl = () => {
    const configuredUrl = process.env.EXPO_PUBLIC_API_BASE_URL?.trim();
    if (configuredUrl) {
        return configuredUrl.replace(/\/$/, '');
    }

    if (Platform.OS === 'android') {
        return 'http://192.168.0.106:8080';
    }

    return 'http://localhost:8080';
};

const API_BASE_URL = getApiBaseUrl();

export default function LoginScreen({ navigation }) {
    const [role, setRole] = useState('patient');
    const [loginId, setLoginId] = useState('');
    const [password, setPassword] = useState('');
    const [loginMessage, setLoginMessage] = useState('');

    const handleLogin = async () => {
        setLoginMessage('');
        if (!loginId || !password) {
            setLoginMessage('Please fill in all fields.');
            Alert.alert('Login Failed', 'Please fill in all fields.');
            return;
        }

        let user;

        try {
            const response = await fetch(`${API_BASE_URL}/api/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({ role, loginId, password }).toString(),
                });
            const result = await response.json();

            if (!response.ok || !result.success) {
                setLoginMessage(result.message || 'Invalid login credentials.');
                Alert.alert('Login Failed', result.message || 'Invalid login credentials.');
                return;
            }

            user = result;
        } catch {
            const errorMessage = `Cannot reach the API server at ${API_BASE_URL}. Start the Java backend on port 8080, and if you're using a phone, change EXPO_PUBLIC_API_BASE_URL to your computer's local IP.`;
            setLoginMessage(errorMessage);
            Alert.alert('Login Failed', 'Unable to connect to the server.');
            return;
        }

        navigation.replace('StudentProfile', { user });
    };

    const RadioButton = ({ value, label }: any) => (
        <TouchableOpacity
            style={styles.radioContainer}
            onPress={() => setRole(value)}
        >
            <View
                style={[
                    styles.radio,
                    role === value && styles.radioSelected,
                ]}
            />
            <Text>{label}</Text>
        </TouchableOpacity>
    );

    return (
        <View style={styles.container}>
            <View style={styles.formContainer}>

                <Text style={styles.heading}>User Login</Text>
                {loginMessage ? <Text style={styles.errorText}>{loginMessage}</Text> : null}

                <Text style={styles.label}>Login As</Text>

                <View style={styles.roleRow}>
                    <RadioButton value="doctor" label="Doctor" />
                    <RadioButton value="admin" label="Admin" />
                    <RadioButton value="patient" label="Patient" />
                </View>

                <Text style={styles.label}>
                    Doctor ID / Admin Username / Patient Email
                </Text>

                <TextInput
                    style={styles.input}
                    placeholder="Enter your ID / Username / Email"
                    value={loginId}
                    onChangeText={setLoginId}
                />

                <Text style={styles.label}>Password</Text>

                <TextInput
                    secureTextEntry
                    style={styles.input}
                    placeholder="Enter Password"
                    value={password}
                    onChangeText={setPassword}
                />

                <TouchableOpacity
                    style={styles.loginButton}
                    onPress={handleLogin}
                >
                    <Text style={styles.loginText}>Login</Text>
                </TouchableOpacity>

                <Text style={styles.or}>OR</Text>

                <TouchableOpacity
                    style={styles.signupButton}
                    onPress={() => navigation.navigate('PatientRegistrationScreen')}
                >
                    <Text style={styles.signupText}>
                        Patient Signup
                    </Text>
                </TouchableOpacity>

            </View>

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 25,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F5F7FA',
    },


    formContainer: {
        width: '100%',
        maxWidth: 420,
        marginTop: 30,
    },


    heading: {
        fontSize: 28,
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 35,
    },

    errorText: {
        color: '#B00020',
        textAlign: 'center',
        marginBottom: 10,
    },

    label: {
        fontWeight: '600',
        marginBottom: 8,
        marginTop: 10,
    },

    roleRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 25,
    },

    radioContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },

    radio: {
        width: 20,
        height: 20,
        borderRadius: 10,
        borderWidth: 2,
        marginRight: 6,
    },

    radioSelected: {
        backgroundColor: '#1565C0',
    },

    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        paddingHorizontal: 12,
        height: 50,
        backgroundColor: '#fff',
        marginBottom: 15,
    },

    loginButton: {
        backgroundColor: '#1565C0',
        padding: 15,
        borderRadius: 8,
        marginTop: 10,
    },

    loginText: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: 18,
    },

    or: {
        textAlign: 'center',
        marginVertical: 15,
        fontWeight: 'bold',
    },

    signupButton: {
        borderWidth: 1,
        borderColor: '#1565C0',
        padding: 15,
        borderRadius: 8,
    },

    signupText: {
        color: '#1565C0',
        textAlign: 'center',
        fontWeight: 'bold',
    },
});
