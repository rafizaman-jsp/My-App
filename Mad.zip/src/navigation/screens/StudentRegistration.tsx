// StudentRegistration.tsx
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Button,
  Modal,
  Pressable,
  Alert,
  ScrollView,
} from "react-native";

type FormErrors = {
  name?: string;
  studentId?: string;
  department?: string;
};

export default function StudentRegistrationScreen({ navigation }) {
  const [name, setName] = useState("");
  const [studentId, setStudentId] = useState("");
  const [department, setDepartment] = useState("");

  const [modalVisible, setModalVisible] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});

  const validateForm = () => {
    const newErrors: FormErrors = {};

    // Name Validation
    if (!name.trim()) {
      newErrors.name = "Student Name is required";
    } else if (!/^[a-zA-Z ]{2,}$/.test(name.trim())) {
      newErrors.name = "Enter a valid name (letters only)";
    }

    // Student ID Validation
    if (!studentId.trim()) {
      newErrors.studentId = "Student ID is required";
    } else if (!/^\d{6,12}$/.test(studentId.trim())) {
      newErrors.studentId = "Student ID must contain 6 to 12 digits";
    }

    // Department Validation
    if (!department.trim()) {
      newErrors.department = "Department is required";
    } else if (!/^[a-zA-Z ]{2,}$/.test(department.trim())) {
      newErrors.department =
        "Enter a valid department name (letters only)";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      setModalVisible(true);
    } else {
      Alert.alert(
        "Validation Error",
        "Please correct the highlighted fields."
      );
    }
  };

  const closeModal = () => {
    setModalVisible(false);

    // Optional: Clear the form after closing
    setName("");
    setStudentId("");
    setDepartment("");
    setErrors({});
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Student Registration</Text>

      {/* Student Name */}
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Student Name</Text>

        <TextInput
          style={[styles.input, errors.name && styles.inputError]}
          placeholder="Enter student name"
          value={name}
          onChangeText={setName}
        />

        {errors.name && (
          <Text style={styles.errorText}>{errors.name}</Text>
        )}
      </View>

      {/* Student ID */}
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Student ID</Text>

        <TextInput
          style={[
            styles.input,
            errors.studentId && styles.inputError,
          ]}
          placeholder="Enter student ID"
          value={studentId}
          onChangeText={setStudentId}
          keyboardType="number-pad"
          maxLength={12}
        />

        {errors.studentId && (
          <Text style={styles.errorText}>
            {errors.studentId}
          </Text>
        )}
      </View>

      {/* Department */}
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Department</Text>

        <TextInput
          style={[
            styles.input,
            errors.department && styles.inputError,
          ]}
          placeholder="Enter department"
          value={department}
          onChangeText={setDepartment}
        />

        {errors.department && (
          <Text style={styles.errorText}>
            {errors.department}
          </Text>
        )}
      </View>

      {/* Submit Button */}
      <View style={styles.buttonContainer}>
        <Button title="Submit" onPress={handleSubmit} />
      </View>

      {/* Live Preview */}
      <View style={styles.preview}>
        <Text style={styles.previewTitle}>
          Entered Information
        </Text>

        <Text style={styles.info}>Name: {name}</Text>
        <Text style={styles.info}>
          Student ID: {studentId}
        </Text>
        <Text style={styles.info}>
          Department: {department}
        </Text>
      </View>

      <View style={styles.backButton}>
        <Button title="Go Back" onPress={() => navigation.goBack()} />
      </View>

      {/* Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
      >
        <View style={styles.modalBackground}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>
              Student Information
            </Text>

            <Text style={styles.modalText}>
              Name: {name}
            </Text>

            <Text style={styles.modalText}>
              Student ID: {studentId}
            </Text>

            <Text style={styles.modalText}>
              Department: {department}
            </Text>

            <Pressable
              style={styles.closeButton}
              onPress={closeModal}
            >
              <Text style={styles.closeButtonText}>
                Close
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 20,
    backgroundColor: "#F5F5F5",
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 25,
    color: "#1976D2",
  },

  inputGroup: {
    marginBottom: 15,
  },

  label: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 5,
  },

  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 6,
    padding: 10,
    fontSize: 16,
    backgroundColor: "#fff",
  },

  inputError: {
    borderColor: "red",
  },

  errorText: {
    color: "red",
    fontSize: 14,
    marginTop: 5,
  },

  buttonContainer: {
    marginVertical: 20,
  },

  preview: {
    backgroundColor: "#FFFFFF",
    padding: 15,
    borderRadius: 10,
    elevation: 3,
  },

  previewTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },

  info: {
    fontSize: 16,
    marginBottom: 6,
  },

  modalBackground: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
  },

  modalContainer: {
    width: "85%",
    backgroundColor: "#FFFFFF",
    padding: 20,
    borderRadius: 12,
    alignItems: "center",
  },

  modalTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1976D2",
    marginBottom: 20,
  },

  modalText: {
    fontSize: 18,
    marginBottom: 10,
  },

  closeButton: {
    backgroundColor: "#1976D2",
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 20,
  },

  closeButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
  },

  backButton: {
    marginTop: 15,
  },
});