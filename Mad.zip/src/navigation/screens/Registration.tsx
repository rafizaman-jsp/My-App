// registration.tsx
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Button,
  Image,
  KeyboardAvoidingView,
  ScrollView,
  Platform,
} from "react-native";

type FormErrors = {
  name?: string;
  studentId?: string;
  email?: string;
  password?: string;
};

export default function RegistrationScreen({ navigation }) {
  const [name, setName] = useState("");
  const [studentId, setStudentId] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [errors, setErrors] = useState<FormErrors>({});


  const validateForm = () => {
    const newErrors: FormErrors = {};

    if (!name.trim()) newErrors.name = "Student Name is required";
    else if (!/^[a-zA-Z ]{2,}$/.test(name.trim())) {
      newErrors.name = "Enter a valid name (letters only)";
    }

    if (!studentId.trim()) newErrors.studentId = "Student ID is required";
    else if (!/^\d{6,12}$/.test(studentId.trim())) {
      newErrors.studentId = "Student ID must contain 6 to 12 digits";
    }

    if (!email.trim()) newErrors.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = "Enter a valid email address";
    }

    if (!password) newErrors.password = "Password is required";
    else if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(password)) {
      newErrors.password =
        "Use 8+ characters with uppercase, lowercase, and a number";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };


  const handleRegister = () => {
    if (validateForm()) {
      console.log("Registration Successful");

      setName("");
      setStudentId("");
      setEmail("");
      setPassword("");
      setErrors({});
    }
  };


  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Image
          source={require("../../assets/IUSlogo.png")}
          style={styles.logo}
          resizeMode="contain"
        />


        <Text style={styles.title}>Student Registration</Text>


        <View style={styles.inputGroup}>
          <Text style={styles.label}>Student Name</Text>
          <TextInput
            style={[styles.input, errors.name && styles.inputError]}
            placeholder="Enter student name"
            value={name}
            onChangeText={setName}
          />
          {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}
        </View>


        <View style={styles.inputGroup}>
          <Text style={styles.label}>Student ID</Text>
          <TextInput
            style={[styles.input, errors.studentId && styles.inputError]}
            placeholder="Enter student ID"
            value={studentId}
            onChangeText={setStudentId}
            keyboardType="number-pad"
            maxLength={12}
          />
          {errors.studentId && (
            <Text style={styles.errorText}>{errors.studentId}</Text>
          )}
        </View>


        <View style={styles.inputGroup}>
          <Text style={styles.label}>Email</Text>
          <TextInput
            style={[styles.input, errors.email && styles.inputError]}
            placeholder="Enter email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
          />
          {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}
        </View>


        <View style={styles.inputGroup}>
          <Text style={styles.label}>Password</Text>
          <TextInput
            style={[styles.input, errors.password && styles.inputError]}
            placeholder="Enter password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoComplete="new-password"
          />
          {errors.password && (
            <Text style={styles.errorText}>{errors.password}</Text>
          )}
        </View>


        <Button title="Register" onPress={handleRegister} />
        <View style={styles.backButton}>
          <Button title="Go Back" onPress={() => navigation.goBack()} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 20,
  },
  logo: {
    width: 260,
    height: 100,
    alignSelf: "center",
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 10,
    fontSize: 16,
  },
  inputError: {
    borderColor: "red",
  },
  errorText: {
    color: "red",
    fontSize: 14,
    marginTop: 5,
  },
  backButton: {
    marginTop: 15,
  },
});
